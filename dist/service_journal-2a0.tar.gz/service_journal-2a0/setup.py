from setuptools import setup, find_packages
setup(
    name="service_journal",
    version="2_alpha",
    packages=find_packages(),
)
